export class User {
    email: string = '';
    name: string = '';
}
